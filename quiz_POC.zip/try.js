window.onload = initializeBody;
function initializeBody () {
	document.getElementById("r5").onclick = R1; 
	
}
function R1() {
//$("#1").removeClass("hidden");
	$('#select-type').show(1000).delay(1000).hide(1000);
	//document.getElementById("#1").style.display = "block";
	//document.getElementById("#select-type").style.display = "none";
	 //alert("HAHA"); 
}